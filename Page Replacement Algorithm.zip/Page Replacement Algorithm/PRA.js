var hits, faults ,flag ,hf ,res ,array ,arrlen ,frames, pages, selected;

function fetch() {
    document.getElementById('hits').innerHTML = "";
    document.getElementById('faults').innerHTML = "";
    document.getElementById('schedule').innerHTML = "";
    document.getElementById('hitrate').innerHTML = "";
    document.getElementById('faultrate').innerHTML = "";

    frames=document.getElementById("frames").value;
    pages=document.getElementById("pageids").value;
    var sel=document.getElementById("algo");
    selected=sel.options[sel.selectedIndex].text;
    if(frames=="" || pages==""){
        alert("Values in array or frames cannot be empty");
    }
    else if(frames<=0){
        alert("Frames cannot be less than or equal to zero");
    }
    else{
        array=pages.split(' ').map(Number);
        arrlen=array.length;
        hf=new Array(arrlen);
        res=new Array(arrlen+1);
        for (let i = 0; i <= arrlen; i++) {
            res[i] = new Array(frames);
        }
        for (let i=0 ; i<frames ; i++) {
            res[0][i] = -1;
        }
        hits=0;
        faults=0;
        flag=0;
        if(selected=="First In First Out"){
            FIFO();
        }
        else if(selected=="Optimal Page Replacement"){
            OPR();
        }
        else if(selected=="Most Recently Used"){
            MRU();
        }
        else{
            LRU();
        }
    }
}
document.getElementById("but").addEventListener("click",fetch);

function FIFO() {
    var prevcall = new Map();
    for (let i=0 ; i<arrlen ; i++){
        flag=0;
        for (let j = 0; j < frames ; j++) {
            if(res[i][j]==array[i]){
                hits++;
                flag=1;
                break;
            }
        }

        if(flag==0){
            faults++;
            empty=0;
            for (let j = 0; j < frames; j++) {
                if(res[i][j]==-1){
                    empty++;
                }
            }
            if(empty){
                for (let j = 0; j < frames; j++) {
                    if(flag==0 && res[i][j]==-1){
                        res[i+1][j]=array[i];
                        prevcall.set(j, i);
                        flag=1;
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            else{
                var min=100000, idx;
                for (let j = 0; j < frames; j++) {
                    if(min>prevcall.get(j)){
                        min=prevcall.get(j);
                        idx=j;
                    }
                }
                for (let j = 0; j < frames; j++) {
                    if(j==idx){
                        res[i+1][j]=array[i];
                        prevcall.set(j, i);
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            hf[i]='*';
        }
        else{
            for (let j = 0; j < frames; j++) {
                res[i+1][j]=res[i][j];
            }
            hf[i]='-';
        }
    }
    show();
}

function MRU() {
    var recentcall;
    for (let i=0 ; i<arrlen ; i++){
        flag=0;
        for (let j = 0; j < frames ; j++) {
            if(res[i][j]==array[i]){
                recentcall=j;
                hits++;
                flag=1;
                break;
            }
        }

        if(flag==0){
            faults++;
            empty=0;
            for (let j = 0; j < frames; j++) {
                if(res[i][j]==-1){
                    empty++;
                }
            }
            if(empty){
                for (let j = 0; j < frames; j++) {
                    if(flag==0 && res[i][j]==-1){
                        res[i+1][j]=array[i];
                        recentcall=j;
                        flag=1;
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            else{
                for (let j = 0; j < frames; j++) {
                    if(j==recentcall){
                        res[i+1][j]=array[i];
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            hf[i]='*';
        }
        else{
            for (let j = 0; j < frames; j++) {
                res[i+1][j]=res[i][j];
            }
            hf[i]='-';
        }
    }
    show();
}

function LRU() {
    var prevcall = new Map();
    for (let i=0 ; i<arrlen ; i++){
        flag=0;
        for (let j = 0; j < frames ; j++) {
            if(res[i][j]==array[i]){
                prevcall.set(j, i);
                hits++;
                flag=1;
                break;
            }
        }

        if(flag==0){
            faults++;
            empty=0;
            for (let j = 0; j < frames; j++) {
                if(res[i][j]==-1){
                    empty++;
                }
            }
            if(empty){
                for (let j = 0; j < frames; j++) {
                    if(flag==0 && res[i][j]==-1){
                        res[i+1][j]=array[i];
                        prevcall.set(j, i);
                        flag=1;
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            else{
                var min=100000, idx;
                for (let j = 0; j < frames; j++) {
                    if(min>prevcall.get(j)){
                        min=prevcall.get(j);
                        idx=j;
                    }
                }
                for (let j = 0; j < frames; j++) {
                    if(j==idx){
                        res[i+1][j]=array[i];
                        prevcall.set(j, i);
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            hf[i]='*';
        }
        else{
            for (let j = 0; j < frames; j++) {
                res[i+1][j]=res[i][j];
            }
            hf[i]='-';
        }
    }
    show();
}

function OPR() {
    for (let i=0 ; i<arrlen ; i++){
        flag=0;
        for (let j = 0; j < frames ; j++) {
            if(res[i][j]==array[i]){
                hits++;
                flag=1;
                break;
            }
        }

        if(flag==0){
            faults++;
            empty=0;
            for (let j = 0; j < frames; j++) {
                if(res[i][j]==-1){
                    empty++;
                }
            }
            if(empty){
                for (let j = 0; j < frames; j++) {
                    if(flag==0 && res[i][j]==-1){
                        res[i+1][j]=array[i];
                        flag=1;
                    }
                    else{
                        res[i+1][j]=res[i][j];
                    }
                }
            }
            else{
                var nextcall = new Map();
                for (let j = 0; j < frames; j++) {
                    nextcall.set(res[i][j], arrlen);
                }
                for (let j = i+1; j < arrlen; j++) {
                    for (let k = 0; k < frames; k++) {
                        if(res[i][k]==array[j]){
                            nextcall.set(res[i][k], Math.min(j, nextcall.get(res[i][k])));
                        }
                    }
                }
                var maxi = 0;
                var index = 0;
                for (let j = 0; j < frames; j++) {
                    if(maxi<nextcall.get(res[i][j])){
                        maxi=nextcall.get(res[i][j]);
                        index=j;
                    }
                }
                for (let j = 0; j < frames; j++) {
                    if(j!=index){
                        res[i+1][j]=res[i][j];
                    }
                    else{
                        res[i+1][j]=array[i];
                    }
                }
            }
            hf[i]='*';
        }
        else{
            for (let j = 0; j < frames; j++) {
                res[i+1][j]=res[i][j];
            }
            hf[i]='-';
        }
    }
    show();
}

function show() {
    document.getElementById("hits").innerHTML = "Number of Page Hits (-): "+hits;
    document.getElementById("faults").innerHTML = "Number of Page Faults (*): "+faults;
    document.getElementById("hitrate").innerHTML = "Hit Rate: "+hits+"/"+arrlen+" = "+((hits/arrlen)*100).toFixed(2)+"%";
    document.getElementById("faultrate").innerHTML = "Fault Rate: "+faults+"/"+arrlen+" = "+((faults/arrlen)*100).toFixed(2)+"%";
    
    var table = document.getElementById("schedule");
    var row = frames;
    var col = arrlen;
    
    for (let rowidx = 0; rowidx <= row+1; rowidx++) {
        var tr=document.createElement('tr');
        if(rowidx==0){
            for (let colidx = 0; colidx < col; colidx++) {
                var td=document.createElement('td');
                var text=document.createTextNode(array[colidx]);
                td.appendChild(text);
                tr.appendChild(td);
            }
        }
        else if(rowidx<=row){
            for (let colidx = 1; colidx <= col; colidx++) {
                var td=document.createElement('td');
                if (res[colidx][rowidx-1]==-1) {
                    var text=document.createTextNode('-');
                }
                else{
                    var text=document.createTextNode(res[colidx][rowidx-1]);
                }
                td.appendChild(text);
                tr.appendChild(td);
            }
        }
        else
        {
            for (let colidx = 0; colidx < col; colidx++) {
                var td=document.createElement('td');
                var text=document.createTextNode(hf[colidx]);
                
                td.appendChild(text);
                if (hf[colidx]='*') {
                    td.style.color='white';
                }
                tr.appendChild(td);
            }
            table.appendChild(tr);
            break;
        }
        table.appendChild(tr);
    }
}